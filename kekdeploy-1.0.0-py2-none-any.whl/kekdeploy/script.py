import tempfile
import webbrowser
def popup():
  html = ('<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>kek&#160&#160&#160)</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
  '<center>&#160&#160&#160</center>'
          )
  with tempfile.NamedTemporaryFile('w', delete=False, suffix='.html') as f:
      url = 'file://' + f.name
      f.write(html)
  return webbrowser.open(url)








