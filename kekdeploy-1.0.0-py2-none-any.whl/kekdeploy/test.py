import script

type(script)